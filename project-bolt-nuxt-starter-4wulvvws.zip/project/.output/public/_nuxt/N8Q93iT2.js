import{U as t,J as o,q as a}from"./npYQabhD.js";const n=t((s,u)=>{const{isLoggedIn:e}=o();if(!e.value)return a("/login")});export{n as default};
